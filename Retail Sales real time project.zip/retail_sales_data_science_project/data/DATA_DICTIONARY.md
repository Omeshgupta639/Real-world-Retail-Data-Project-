# Data Dictionary

| Column | Description |
|---|---|
| InvoiceNo | Transaction/invoice identifier; cancellations are marked with `C` |
| StockCode | Product identifier |
| Description | Product description |
| Quantity | Number of units in the transaction |
| InvoiceDate | Transaction date and time |
| UnitPrice | Product price per unit in GBP |
| CustomerID | Customer identifier |
| Country | Customer country |
| Revenue | Derived field: Quantity × UnitPrice |

`sample_online_retail.csv` is a small demonstration sample included so the repository can be run immediately. The full UCI dataset is downloaded separately with `src/download_data.py`.
