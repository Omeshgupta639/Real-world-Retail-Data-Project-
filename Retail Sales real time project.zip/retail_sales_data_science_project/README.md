# Real-World Retail Sales Data Science Project

## Project Overview

This project performs an end-to-end analysis of an online retail transaction dataset. It covers data acquisition, cleaning, exploratory data analysis, customer/product/country analysis, revenue trends, visualization, and a simple monthly sales forecasting model.

### Dataset

The project uses the **Online Retail** dataset from the UCI Machine Learning Repository.

- Source: UCI Machine Learning Repository
- Dataset: Online Retail
- Transactions: 541,909
- Period: 01-Dec-2010 to 09-Dec-2011
- Domain: Retail / E-commerce
- License: CC BY 4.0
- DOI: https://doi.org/10.24432/C5BW33

The full dataset is intentionally not committed to this repository because the original XLSX file is large. Run the download script to obtain it automatically.

## Key Questions

1. How do sales/revenue change over time?
2. Which products generate the highest revenue?
3. Which countries contribute most to revenue?
4. What are the transaction, customer, and product patterns?
5. Can monthly revenue be forecast using historical sales features?

## Project Structure

```text
retail_sales_data_science_project/
├── data/
│   ├── sample_online_retail.csv
│   └── online_retail.xlsx              # downloaded locally, not committed
├── notebooks/
│   └── retail_sales_analysis.ipynb
├── outputs/
│   ├── monthly_revenue.png
│   ├── top_products.png
│   ├── country_revenue.png
│   └── forecast.png
├── reports/
│   └── analysis_summary.md
├── src/
│   ├── download_data.py
│   └── analyze_retail.py
├── .gitignore
├── LICENSE
├── requirements.txt
└── README.md
```

## Setup

### 1. Clone the repository

```bash
git clone <YOUR_GITHUB_REPOSITORY_URL>
cd retail_sales_data_science_project
```

### 2. Create a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Download the original dataset

```bash
python src/download_data.py
```

This downloads the UCI Online Retail dataset into `data/online_retail.xlsx`.

### 5. Run the analysis

```bash
python src/analyze_retail.py
```

The script generates cleaned analysis outputs and charts inside `outputs/`.

### 6. Run the notebook

```bash
jupyter notebook notebooks/retail_sales_analysis.ipynb
```

## Analysis Workflow

1. Load transaction data
2. Inspect dimensions and missing values
3. Convert date fields
4. Remove cancelled/invalid transactions
5. Remove non-positive quantities/prices
6. Create `Revenue = Quantity × UnitPrice`
7. Analyze monthly revenue
8. Analyze top-selling products
9. Analyze country-level revenue
10. Calculate customer metrics
11. Build a simple monthly revenue forecasting model
12. Visualize findings and document conclusions

## Expected Findings

The exact results depend on the full UCI dataset. The analysis is designed to identify:

- Seasonal/monthly sales patterns
- High-revenue products
- Geographic concentration of sales
- Customer purchasing behavior
- Revenue trends and short-term forecast estimates

## Academic / Portfolio Use

This project demonstrates practical skills in:

- Python
- Pandas
- NumPy
- Data cleaning
- Exploratory Data Analysis
- Feature engineering
- Data visualization
- Regression-based forecasting
- Business interpretation
- GitHub project organization

## Dataset Citation

Chen, D. (2015). **Online Retail**. UCI Machine Learning Repository. https://doi.org/10.24432/C5BW33

Dataset license: Creative Commons Attribution 4.0 International (CC BY 4.0).

## Author

**Omesh Gupta**  
B.Tech-M.Tech in Computer Science Engineering (Cyber Security)
