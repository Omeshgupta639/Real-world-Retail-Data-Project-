# Analysis Summary

## Data Source
project demonstration sample

## Cleaning
- Rows before cleaning: 1,200
- Rows after cleaning: 1,175
- Removed cancelled, non-positive, and invalid transaction records.
- Created `Revenue = Quantity × UnitPrice`.

## Core Metrics
- Total revenue: 60,673.05
- Unique invoices: 600
- Unique products: 10
- Unique customers: 1,071
- Countries represented: 6

## Business Findings
- The monthly revenue chart shows how sales vary over the observed period.
- The top-product table identifies the products with the largest revenue contribution.
- The country analysis highlights the geographic concentration of sales.
- Customer metrics provide a foundation for segmentation and retention analysis.

## Forecasting
Forecast Model
Source: project demonstration sample
Model: Linear Regression using MonthIndex and one-month revenue lag
MAE: 1,404.84
RMSE: 2,168.50
Next-month forecast: 3,321.82


## Conclusion
The project demonstrates an end-to-end retail analytics workflow, from transaction cleaning and feature engineering to business-oriented visualization and simple predictive modeling.
