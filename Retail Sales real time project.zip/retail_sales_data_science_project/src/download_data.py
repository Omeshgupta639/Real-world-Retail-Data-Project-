from pathlib import Path
from ucimlrepo import fetch_ucirepo

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
DATA_DIR.mkdir(exist_ok=True)
OUTPUT = DATA_DIR / "online_retail.xlsx"

dataset = fetch_ucirepo(id=352)

# The UCI package exposes the dataset as pandas dataframes.
# Reconstruct the complete table using the published feature columns.
df = dataset.data.features.copy()

# Some versions expose CustomerID through the features dataframe.
if "CustomerID" not in df.columns and getattr(dataset.data, "targets", None) is not None:
    targets = dataset.data.targets
    if "CustomerID" in targets.columns:
        df["CustomerID"] = targets["CustomerID"]

df.to_excel(OUTPUT, index=False)
print(f"Saved dataset to: {OUTPUT}")
print(f"Rows: {len(df):,}")
