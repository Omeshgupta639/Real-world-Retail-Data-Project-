from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "outputs"
OUT_DIR.mkdir(exist_ok=True)

xlsx = DATA_DIR / "online_retail.xlsx"
csv_sample = DATA_DIR / "sample_online_retail.csv"

if xlsx.exists():
    df = pd.read_excel(xlsx)
    source = "UCI Online Retail"
else:
    df = pd.read_csv(csv_sample)
    source = "project demonstration sample"

df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"], errors="coerce")
df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce")
df["UnitPrice"] = pd.to_numeric(df["UnitPrice"], errors="coerce")

before = len(df)
df = df.dropna(subset=["InvoiceDate", "Quantity", "UnitPrice"])
df = df[df["Quantity"] > 0]
df = df[df["UnitPrice"] > 0]
df = df[~df["InvoiceNo"].astype(str).str.upper().str.startswith("C")]
df["Revenue"] = df["Quantity"] * df["UnitPrice"]
df["Month"] = df["InvoiceDate"].dt.to_period("M").dt.to_timestamp()
cleaned = len(df)

monthly = df.groupby("Month", as_index=False)["Revenue"].sum()
monthly.to_csv(OUT_DIR / "monthly_revenue.csv", index=False)

top_products = (
    df.groupby("Description", as_index=False)["Revenue"]
      .sum()
      .sort_values("Revenue", ascending=False)
      .head(10)
)
top_products.to_csv(OUT_DIR / "top_products.csv", index=False)

country_revenue = (
    df.groupby("Country", as_index=False)["Revenue"]
      .sum()
      .sort_values("Revenue", ascending=False)
      .head(10)
)
country_revenue.to_csv(OUT_DIR / "country_revenue.csv", index=False)

customer_metrics = (
    df.groupby("CustomerID")
      .agg(
          TotalRevenue=("Revenue", "sum"),
          Orders=("InvoiceNo", "nunique"),
          Units=("Quantity", "sum")
      )
      .sort_values("TotalRevenue", ascending=False)
)
customer_metrics.to_csv(OUT_DIR / "customer_metrics.csv")

# Monthly revenue visualization
plt.figure(figsize=(11, 5))
plt.plot(monthly["Month"], monthly["Revenue"], marker="o")
plt.title("Monthly Revenue")
plt.xlabel("Month")
plt.ylabel("Revenue")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(OUT_DIR / "monthly_revenue.png", dpi=160)
plt.close()

# Top products visualization
plot_products = top_products.sort_values("Revenue")
plt.figure(figsize=(10, 6))
plt.barh(plot_products["Description"].str.slice(0, 35), plot_products["Revenue"])
plt.title("Top 10 Products by Revenue")
plt.xlabel("Revenue")
plt.tight_layout()
plt.savefig(OUT_DIR / "top_products.png", dpi=160)
plt.close()

# Country visualization
plot_countries = country_revenue.sort_values("Revenue")
plt.figure(figsize=(9, 6))
plt.barh(plot_countries["Country"], plot_countries["Revenue"])
plt.title("Top 10 Countries by Revenue")
plt.xlabel("Revenue")
plt.tight_layout()
plt.savefig(OUT_DIR / "country_revenue.png", dpi=160)
plt.close()

# Simple time-series regression using lagged monthly revenue
forecast = monthly.copy()
forecast["MonthIndex"] = np.arange(len(forecast))
forecast["Lag1"] = forecast["Revenue"].shift(1)
forecast = forecast.dropna().reset_index(drop=True)

if len(forecast) >= 6:
    split = max(4, int(len(forecast) * 0.8))
    train = forecast.iloc[:split]
    test = forecast.iloc[split:]

    model = LinearRegression()
    model.fit(train[["MonthIndex", "Lag1"]], train["Revenue"])
    pred = model.predict(test[["MonthIndex", "Lag1"]])

    mae = mean_absolute_error(test["Revenue"], pred)
    rmse = np.sqrt(mean_squared_error(test["Revenue"], pred))

    # Fit final model for one-step-ahead forecast
    final_model = LinearRegression()
    final_model.fit(forecast[["MonthIndex", "Lag1"]], forecast["Revenue"])
    next_index = forecast["MonthIndex"].max() + 1
    next_lag = monthly["Revenue"].iloc[-1]
    next_forecast = float(final_model.predict([[next_index, next_lag]])[0])

    forecast_dates = test["Month"].tolist()
    plt.figure(figsize=(11, 5))
    plt.plot(train["Month"], train["Revenue"], label="Train")
    plt.plot(test["Month"], test["Revenue"], label="Actual")
    plt.plot(test["Month"], pred, label="Predicted")
    plt.title("Monthly Revenue Forecast Evaluation")
    plt.xlabel("Month")
    plt.ylabel("Revenue")
    plt.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(OUT_DIR / "forecast.png", dpi=160)
    plt.close()

    forecast_summary = f"""Forecast Model
Source: {source}
Model: Linear Regression using MonthIndex and one-month revenue lag
MAE: {mae:,.2f}
RMSE: {rmse:,.2f}
Next-month forecast: {next_forecast:,.2f}
"""
else:
    forecast_summary = "Not enough monthly observations for the forecast model."

summary = f"""# Analysis Summary

## Data Source
{source}

## Cleaning
- Rows before cleaning: {before:,}
- Rows after cleaning: {cleaned:,}
- Removed cancelled, non-positive, and invalid transaction records.
- Created `Revenue = Quantity × UnitPrice`.

## Core Metrics
- Total revenue: {df["Revenue"].sum():,.2f}
- Unique invoices: {df["InvoiceNo"].nunique():,}
- Unique products: {df["StockCode"].nunique():,}
- Unique customers: {df["CustomerID"].nunique():,}
- Countries represented: {df["Country"].nunique():,}

## Business Findings
- The monthly revenue chart shows how sales vary over the observed period.
- The top-product table identifies the products with the largest revenue contribution.
- The country analysis highlights the geographic concentration of sales.
- Customer metrics provide a foundation for segmentation and retention analysis.

## Forecasting
{forecast_summary}

## Conclusion
The project demonstrates an end-to-end retail analytics workflow, from transaction cleaning and feature engineering to business-oriented visualization and simple predictive modeling.
"""
(OUT_DIR.parent / "reports" / "analysis_summary.md").write_text(summary, encoding="utf-8")

print(f"Analysis completed using {source}.")
print(summary)
